package canteen2;


public class Plate extends MenuOptions{
	/**
	 * @param typeFood
	 * @param name
	 * @param cost
	 */
	String typeOfPlate;
	
	public Plate(String typeFood, String name,String typeOfPlate) {
		super(typeFood, name);
		this.typeOfPlate = typeOfPlate;
	}

	/**
	 * @return the typeOfPlate
	 */
	public String getTypeOfPlate() {
		return typeOfPlate;
	}

	/**
	 * @param typeOfPlate the typeOfPlate to set
	 */
	public void setTypeOfPlate(String typeOfPlate) {
		this.typeOfPlate = typeOfPlate;
	}

	@Override
	public String toString() {
		return "Plate [typeOfPlate=" + typeOfPlate + "]";
	}

	
	
}