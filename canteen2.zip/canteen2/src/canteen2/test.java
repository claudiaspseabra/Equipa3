/**
 * 
 */
package canteen2;

/**
 * 
 */
public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


	}

}
