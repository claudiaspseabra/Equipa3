package canteen2;


public class Admin extends User{
	/**
	 * @param password
	 * @param first_Name
	 * @param surname
	 * @param username
	 * @param idNumber
	 */
	public Admin(String password, String first_Name, String surname, String username, int idNumber) {
		super(password, first_Name, surname, username);
		this.idNumber = idNumber;
	}

	private int idNumber;

	/**
	 * @return the idNumber
	 */
	public int getIdNumber() {
		return idNumber;
	}

	/**
	 * @param idNumber the idNumber to set
	 */
	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}

	@Override
	public String toString() {
		return "Admin [idNumber=" + idNumber + "]";
	}

}