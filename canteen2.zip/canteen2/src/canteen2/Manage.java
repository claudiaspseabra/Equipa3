/**
 * 
 */
package canteen2;

import java.util.ArrayList;


/**
 * 
 */
public class Manage { // Manage Menus like delete a menu or something
	/**
	 * @param options
	 */
	private ArrayList<Menu>menus;
	private ArrayList<User>users;
	
	
	public Manage() {
		menus= new ArrayList<Menu>();
		users = new ArrayList<User>();
	}
	

	
	// create menu method
	
	public void addMenu(Menu newMenu) {
			menus.add(newMenu);
	}
	
	//  print method
	
	public void printMenu() {
		for(Menu o: menus) {
			System.out.println(o);
		}
	}



	// delete menu
	
	public void removeMenu(Menu menu1) {
		if(menus.contains(menu1)) {
			menus.remove(menu1);
			System.out.println(menu1+" removed!");
		}
		else {
			System.out.println(menu1+" not found!");
		}
	}
	
	// register a user method
	public void registerUser(User newUser) {
		users.add(newUser);	
	}

	
	
	
	
	
	
	

}

	
	
	