/**
 * 
 */
package canteen2;

import java.util.ArrayList;


/**
 * 
 */
public class Menu { // Create a menus and manage it
	/**
	 * @param totalPrice
	 * @param menus
	 */
	public Menu() {
		menu = new ArrayList<MenuOptions>();
	}
	/**
	 * @param plateName
	 * @param price
	 * @param drinkName
	 * @param cost
	 */
	private ArrayList<MenuOptions>menu;

	
	// register menu
	
	public void registerOption(MenuOptions newOption) {
		menu.add(newOption);
	}
	
	// print menu options
	
	public String printEntireMenu(){   
		String s = "";
	    for (MenuOptions j:menu){ 
	    	 s = j + "\n";
	   
	    }
		return s; 
    } 
	

	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
}