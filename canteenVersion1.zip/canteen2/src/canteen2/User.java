/**
 * 
 */
package canteen2;

public class User {
	/**
	 * @param password
	 * @param first_Name
	 * @param surname
	 */
	public User(String password, String first_Name, String surname,String username) {
		this.password = password;
		this.first_Name = first_Name;
		this.surname = surname;
		this.username = username;
	}
	/**
	 * @param username
	 * @param password
	 */
	private String password;
	private String first_Name;
	private String surname;
	private String username;
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the first_Name
	 */
	public String getFirst_Name() {
		return first_Name;
	}
	/**
	 * @param first_Name the first_Name to set
	 */
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}
	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

}
