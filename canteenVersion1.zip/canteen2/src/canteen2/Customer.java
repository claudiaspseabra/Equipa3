/**
 * 
 */
package canteen2;

/**
 * 
 */
public class Customer extends User{
	/**
	 * @param password
	 * @param first_Name
	 * @param surname
	 * @param username
	 * @param customersId
	 */
	public Customer(String password, String first_Name, String surname, String username, int customersId) {
		super(password, first_Name, surname, username);
		this.customersId = customersId;
	}

	private int customersId;

	/**
	 * @return the customersId
	 */
	public int getCustomersId() {
		return customersId;
	}

	/**
	 * @param customersId the customersId to set
	 */
	public void setCustomersId(int customersId) {
		this.customersId = customersId;
	}

	@Override
	public String toString() {
		return "Customer [customersId=" + customersId + "]";
	}
}
