package canteen2;


public class Drink extends MenuOptions{
	/**
	 * @param typeFood
	 * @param name
	 * @param cost
	 */
	public Drink(String typeFood, String name, String typeOfDrink) {
		super(typeFood, name);
		this.typeOfDrink = typeOfDrink;
		
	}

	private String typeOfDrink;

	/**
	 * @return the typeOfDrink
	 */
	public String getTypeOfDrink() {
		return typeOfDrink;
	}

	/**
	 * @param typeOfDrink the typeOfDrink to set
	 */
	public void setTypeOfDrink(String typeOfDrink) {
		this.typeOfDrink = typeOfDrink;
	}

	@Override
	public String toString() {
		return "Drink [typeOfDrink=" + typeOfDrink + "]";
	}

}
