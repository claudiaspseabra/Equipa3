/**
 * 
 */
package canteen2;

/**
 * 
 */
public abstract class MenuOptions{ // create a dish/drink/desert
	/**
	 * @param typeFood
	 * @param name
	 */
	public MenuOptions(String typeFood, String name) {
		this.typeFood = typeFood;
		this.name = name;
	}
	private String typeFood;
	private String name;
	/**
	 * @return the typeFood
	 */
	public String getTypeFood() {
		return typeFood;
	}
	/**
	 * @param typeFood the typeFood to set
	 */
	public void setTypeFood(String typeFood) {
		this.typeFood = typeFood;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "MenuOptions [typeFood=" + typeFood + ", name=" + name + super.toString() + "]";
	}
}
