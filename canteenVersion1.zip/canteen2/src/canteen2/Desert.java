package canteen2;


public class Desert extends MenuOptions{
	/**
	 * @param typeFood
	 * @param name
	 * @param cost
	 */
	public Desert(String typeFood, String name, String typeOfDesert) {
		super(typeFood, name);
		this.typeOfDesert = typeOfDesert;
		
	}

	private String typeOfDesert; // ice cream , cake , etc

	/**
	 * @return the typeOfDesert
	 */
	public String getTypeOfDesert() {
		return typeOfDesert;
	}

	/**
	 * @param typeOfDesert the typeOfDesert to set
	 */
	public void setTypeOfDesert(String typeOfDesert) {
		this.typeOfDesert = typeOfDesert;
	}

	@Override
	public String toString() {
		return "Desert [typeOfDesert=" + typeOfDesert + "]";
	}

}